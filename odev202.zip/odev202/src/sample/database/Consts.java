package sample.database;

public class Consts {
    public static final String admins = "admins";
    public static final String employees = "employees";
    public static final String adminsname = "name";
    public static final String admuser = "username";
    public static final String admemail = "email";
    public static final String admpass = "password";
    public static final String empid = "id";
    public static final String emplevel = "level";
    public static final String empdate = "expiredate";

}
