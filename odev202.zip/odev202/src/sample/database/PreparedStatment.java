package sample.database;

public class PreparedStatment {
}
